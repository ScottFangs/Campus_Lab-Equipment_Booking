package daoimpl;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import dao.LabDAO;
import factories.DBConnectionFactory;
import model.Lab;

public class LabDAOJdbc implements LabDAO {

    private Connection connection = DBConnectionFactory.getConnection();

    @Override
    public void save(Lab lab) {
        try {
            String sql = "INSERT INTO Labs (labId, labName, campus, seatCapacity) VALUES (?, ?, ?, ?)";
            PreparedStatement ps = connection.prepareStatement(sql);
            ps.setString(1, lab.getLabId());
            ps.setString(2, lab.getLabName());
            ps.setString(3, lab.getCampus());
            ps.setInt(4, lab.getSeatCapacity());
            ps.executeUpdate();
            System.out.println("Lab saved with JDBC.");
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @Override
    public void update(Lab lab) {
        try {
            String sql = "UPDATE Labs SET labName=?, campus=?, seatCapacity=? WHERE labId=?";
            PreparedStatement ps = connection.prepareStatement(sql);
            ps.setString(1, lab.getLabName());
            ps.setString(2, lab.getCampus());
            ps.setInt(3, lab.getSeatCapacity());
            ps.setString(4, lab.getLabId());
            ps.executeUpdate();
            System.out.println("Lab updated with JDBC.");
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @Override
    public void delete(String labId) {
        try {
            String sql = "DELETE FROM Labs WHERE labId=?";
            PreparedStatement ps = connection.prepareStatement(sql);
            ps.setString(1, labId);
            ps.executeUpdate();
            System.out.println("Lab deleted with JDBC.");
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @Override
    public Lab findById(String labId) {
        try {
            String sql = "SELECT * FROM Labs WHERE labId=?";
            PreparedStatement ps = connection.prepareStatement(sql);
            ps.setString(1, labId);
            ResultSet rs = ps.executeQuery();

            if (rs.next()) {
                return new Lab(
                        rs.getString("labId"),
                        rs.getString("labName"),
                        rs.getString("campus"),
                        rs.getInt("seatCapacity")
                );
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }

    @Override
    public List<Lab> findAll() {
        List<Lab> labs = new ArrayList<>();
        try {
            String sql = "SELECT * FROM Labs";
            PreparedStatement ps = connection.prepareStatement(sql);
            ResultSet rs = ps.executeQuery();

            while (rs.next()) {
                labs.add(new Lab(
                        rs.getString("labId"),
                        rs.getString("labName"),
                        rs.getString("campus"),
                        rs.getInt("seatCapacity")
                ));
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return labs;
    }
}
