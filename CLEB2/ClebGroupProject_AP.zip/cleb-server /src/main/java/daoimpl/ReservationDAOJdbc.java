package daoimpl;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import dao.ReservationDAO;
import factories.DBConnectionFactory;
import model.Equipment;
import model.Lab;
import model.Reservation;
import model.ReservationStatus;
import model.User;

public class ReservationDAOJdbc implements ReservationDAO {

    private Connection connection = DBConnectionFactory.getConnection();
    private PreparedStatement ps = null;
    private ResultSet rs = null;

    @Override
    public void save(Reservation reservation) {
        try {
            String sql = "INSERT INTO Reservations (reservationId, userId, labId, equipmentId, seatNumber, bookingDate, startTime, endTime, status) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)";
            ps = connection.prepareStatement(sql);
            ps.setString(1, reservation.getReservationId());
            ps.setString(2, reservation.getUser().getUserId());
            ps.setString(3, reservation.getLab().getLabId());
            ps.setString(4, reservation.getEquipment() == null ? null : reservation.getEquipment().getEquipmentId());
            ps.setString(5, reservation.getSeatNumber());
            ps.setObject(6, reservation.getBookingDate());
            ps.setObject(7, reservation.getStartTime());
            ps.setObject(8, reservation.getEndTime());
            ps.setString(9, reservation.getStatus().name());

            if (ps.executeUpdate() > 0) {
                System.out.println("Reservation saved successfully.");
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @Override
    public void update(Reservation reservation) {
        try {
            String sql = "UPDATE Reservations SET userId=?, labId=?, equipmentId=?, seatNumber=?, bookingDate=?, startTime=?, endTime=?, status=? WHERE reservationId=?";
            ps = connection.prepareStatement(sql);
            ps.setString(1, reservation.getUser().getUserId());
            ps.setString(2, reservation.getLab().getLabId());
            ps.setString(3, reservation.getEquipment() == null ? null : reservation.getEquipment().getEquipmentId());
            ps.setString(4, reservation.getSeatNumber());
            ps.setObject(5, reservation.getBookingDate());
            ps.setObject(6, reservation.getStartTime());
            ps.setObject(7, reservation.getEndTime());
            ps.setString(8, reservation.getStatus().name());
            ps.setString(9, reservation.getReservationId());

            if (ps.executeUpdate() > 0) {
                System.out.println("Reservation updated successfully.");
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @Override
    public void delete(String reservationId) {
        try {
            String sql = "DELETE FROM Reservations WHERE reservationId=?";
            ps = connection.prepareStatement(sql);
            ps.setString(1, reservationId);

            if (ps.executeUpdate() > 0) {
                System.out.println("Reservation deleted successfully.");
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @Override
    public Reservation findById(String reservationId) {
        Reservation reservation = null;

        try {
            String sql = "SELECT * FROM Reservations WHERE reservationId=?";
            ps = connection.prepareStatement(sql);
            ps.setString(1, reservationId);
            rs = ps.executeQuery();

            if (rs.next()) {
                User user = new User();
                user.setUserId(rs.getString("userId"));

                Lab lab = new Lab();
                lab.setLabId(rs.getString("labId"));

                Equipment equipment = null;
                if (rs.getString("equipmentId") != null) {
                    equipment = new Equipment();
                    equipment.setEquipmentId(rs.getString("equipmentId"));
                }

                reservation = new Reservation(
                    rs.getString("reservationId"),
                    user,
                    lab,
                    equipment,
                    rs.getString("seatNumber"),
                    rs.getDate("bookingDate").toLocalDate(),
                    rs.getTime("startTime").toLocalTime(),
                    rs.getTime("endTime").toLocalTime(),
                    ReservationStatus.valueOf(rs.getString("status"))
                );
            }
        } catch (Exception e) {
            e.printStackTrace();
        }

        return reservation;
    }

    @Override
    public List<Reservation> findAll() {
        List<Reservation> reservationList = new ArrayList<Reservation>();

        try {
            String sql = "SELECT * FROM Reservations";
            ps = connection.prepareStatement(sql);
            rs = ps.executeQuery();

            while (rs.next()) {
                User user = new User();
                user.setUserId(rs.getString("userId"));

                Lab lab = new Lab();
                lab.setLabId(rs.getString("labId"));

                Equipment equipment = null;
                if (rs.getString("equipmentId") != null) {
                    equipment = new Equipment();
                    equipment.setEquipmentId(rs.getString("equipmentId"));
                }

                Reservation reservation = new Reservation(
                    rs.getString("reservationId"),
                    user,
                    lab,
                    equipment,
                    rs.getString("seatNumber"),
                    rs.getDate("bookingDate").toLocalDate(),
                    rs.getTime("startTime").toLocalTime(),
                    rs.getTime("endTime").toLocalTime(),
                    ReservationStatus.valueOf(rs.getString("status"))
                );

                reservationList.add(reservation);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }

        return reservationList;
    }

    @Override
    public List<Reservation> findByUser(String userId) {
        List<Reservation> reservationList = new ArrayList<Reservation>();

        try {
            String sql = "SELECT * FROM Reservations WHERE userId=?";
            ps = connection.prepareStatement(sql);
            ps.setString(1, userId);
            rs = ps.executeQuery();

            while (rs.next()) {
                User user = new User();
                user.setUserId(rs.getString("userId"));

                Lab lab = new Lab();
                lab.setLabId(rs.getString("labId"));

                Equipment equipment = null;
                if (rs.getString("equipmentId") != null) {
                    equipment = new Equipment();
                    equipment.setEquipmentId(rs.getString("equipmentId"));
                }

                Reservation reservation = new Reservation(
                    rs.getString("reservationId"),
                    user,
                    lab,
                    equipment,
                    rs.getString("seatNumber"),
                    rs.getDate("bookingDate").toLocalDate(),
                    rs.getTime("startTime").toLocalTime(),
                    rs.getTime("endTime").toLocalTime(),
                    ReservationStatus.valueOf(rs.getString("status"))
                );

                reservationList.add(reservation);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }

        return reservationList;
       
    }

    @Override
    public List<Reservation> findByStatus(ReservationStatus status) {
        List<Reservation> reservationList = new ArrayList<Reservation>();

        try {
            String sql = "SELECT * FROM Reservations WHERE status=?";
            ps = connection.prepareStatement(sql);
            ps.setString(1, status.name());
            rs = ps.executeQuery();

            while (rs.next()) {
                User user = new User();
                user.setUserId(rs.getString("userId"));

                Lab lab = new Lab();
                lab.setLabId(rs.getString("labId"));

                Equipment equipment = null;
                if (rs.getString("equipmentId") != null) {
                    equipment = new Equipment();
                    equipment.setEquipmentId(rs.getString("equipmentId"));
                }

                Reservation reservation = new Reservation(
                    rs.getString("reservationId"),
                    user,
                    lab,
                    equipment,
                    rs.getString("seatNumber"),
                    rs.getDate("bookingDate").toLocalDate(),
                    rs.getTime("startTime").toLocalTime(),
                    rs.getTime("endTime").toLocalTime(),
                    ReservationStatus.valueOf(rs.getString("status"))
                );

                reservationList.add(reservation);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }

        return reservationList;
    }
    @Override
    public void cancelReservation(long reservationId) {
        String sql = "UPDATE reservations SET status = 'CANCELLED' WHERE reservationId = ?";
        try (Connection conn = DriverManager.getConnection(URL, USER, PASSWORD);
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setLong(1, reservationId);
            pstmt.executeUpdate();
            logger.info("Reservation " + reservationId + " cancelled");
        } catch (SQLException e) {
            throw new DatabaseException("Failed to cancel reservation", e);
        }
    }
}