package daoimpl;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import dao.UserDAO;
import factories.DBConnectionFactory;
import model.Role;
import model.User;

public class UserDAOJdbc implements UserDAO {

    private Connection connection = DBConnectionFactory.getConnection();

    @Override
    public void save(User user) {
        try {
            String sql = "INSERT INTO Users (userId, firstName, lastName, email, passwordHash, role) VALUES (?, ?, ?, ?, ?, ?)";
            PreparedStatement ps = connection.prepareStatement(sql);
            ps.setString(1, user.getUserId());
            ps.setString(2, user.getFirstName());
            ps.setString(3, user.getLastName());
            ps.setString(4, user.getEmail());
            ps.setString(5, user.getPasswordHash());
            ps.setString(6, user.getRole().name());
            ps.executeUpdate();
            System.out.println("User saved with JDBC.");
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @Override
    public void update(User user) {
        try {
            String sql = "UPDATE Users SET firstName=?, lastName=?, email=?, passwordHash=?, role=? WHERE userId=?";
            PreparedStatement ps = connection.prepareStatement(sql);
            ps.setString(1, user.getFirstName());
            ps.setString(2, user.getLastName());
            ps.setString(3, user.getEmail());
            ps.setString(4, user.getPasswordHash());
            ps.setString(5, user.getRole().name());
            ps.setString(6, user.getUserId());
            ps.executeUpdate();
            System.out.println("User updated with JDBC.");
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @Override
    public void delete(String userId) {
        try {
            String sql = "DELETE FROM Users WHERE userId=?";
            PreparedStatement ps = connection.prepareStatement(sql);
            ps.setString(1, userId);
            ps.executeUpdate();
            System.out.println("User deleted with JDBC.");
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @Override
    public User findById(String userId) {
        try {
            String sql = "SELECT * FROM Users WHERE userId=?";
            PreparedStatement ps = connection.prepareStatement(sql);
            ps.setString(1, userId);
            ResultSet rs = ps.executeQuery();

            if (rs.next()) {
                return new User(
                        rs.getString("userId"),
                        rs.getString("firstName"),
                        rs.getString("lastName"),
                        rs.getString("email"),
                        rs.getString("passwordHash"),
                        Role.valueOf(rs.getString("role"))
                );
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }

    @Override
    public User findByEmail(String email) {
        try {
            String sql = "SELECT * FROM Users WHERE email=?";
            PreparedStatement ps = connection.prepareStatement(sql);
            ps.setString(1, email);
            ResultSet rs = ps.executeQuery();

            if (rs.next()) {
                return new User(
                        rs.getString("userId"),
                        rs.getString("firstName"),
                        rs.getString("lastName"),
                        rs.getString("email"),
                        rs.getString("passwordHash"),
                        Role.valueOf(rs.getString("role"))
                );
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }

    @Override
    public List<User> findAll() {
        List<User> users = new ArrayList<>();
        try {
            String sql = "SELECT * FROM Users";
            PreparedStatement ps = connection.prepareStatement(sql);
            ResultSet rs = ps.executeQuery();

            while (rs.next()) {
                users.add(new User(
                        rs.getString("userId"),
                        rs.getString("firstName"),
                        rs.getString("lastName"),
                        rs.getString("email"),
                        rs.getString("passwordHash"),
                        Role.valueOf(rs.getString("role"))
                ));
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return users;
    }
}
