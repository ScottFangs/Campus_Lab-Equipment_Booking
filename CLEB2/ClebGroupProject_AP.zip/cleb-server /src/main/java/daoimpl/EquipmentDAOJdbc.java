package daoimpl;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import dao.EquipmentDAO;
import factories.DBConnectionFactory;
import model.Equipment;
import model.Lab;

public class EquipmentDAOJdbc implements EquipmentDAO {

    private Connection connection = DBConnectionFactory.getConnection();

    @Override
    public void save(Equipment equipment) {
        try {
            String sql = "INSERT INTO Equipment (equipmentId, equipmentName, status, labId) VALUES (?, ?, ?, ?)";
            PreparedStatement ps = connection.prepareStatement(sql);
            ps.setString(1, equipment.getEquipmentId());
            ps.setString(2, equipment.getEquipmentName());
            ps.setString(3, equipment.getStatus());
            ps.setString(4, equipment.getLab().getLabId());
            ps.executeUpdate();
            System.out.println("Equipment saved with JDBC.");
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @Override
    public void update(Equipment equipment) {
        try {
            String sql = "UPDATE Equipment SET equipmentName=?, status=?, labId=? WHERE equipmentId=?";
            PreparedStatement ps = connection.prepareStatement(sql);
            ps.setString(1, equipment.getEquipmentName());
            ps.setString(2, equipment.getStatus());
            ps.setString(3, equipment.getLab().getLabId());
            ps.setString(4, equipment.getEquipmentId());
            ps.executeUpdate();
            System.out.println("Equipment updated with JDBC.");
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @Override
    public void delete(String equipmentId) {
        try {
            String sql = "DELETE FROM Equipment WHERE equipmentId=?";
            PreparedStatement ps = connection.prepareStatement(sql);
            ps.setString(1, equipmentId);
            ps.executeUpdate();
            System.out.println("Equipment deleted with JDBC.");
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @Override
    public Equipment findById(String equipmentId) {
        try {
            String sql = "SELECT * FROM Equipment WHERE equipmentId=?";
            PreparedStatement ps = connection.prepareStatement(sql);
            ps.setString(1, equipmentId);
            ResultSet rs = ps.executeQuery();

            if (rs.next()) {
                Lab lab = new Lab();
                lab.setLabId(rs.getString("labId"));

                return new Equipment(
                        rs.getString("equipmentId"),
                        rs.getString("equipmentName"),
                        rs.getString("status"),
                        lab
                );
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }

    @Override
    public List<Equipment> findAll() {
        List<Equipment> equipmentList = new ArrayList<>();
        try {
            String sql = "SELECT * FROM Equipment";
            PreparedStatement ps = connection.prepareStatement(sql);
            ResultSet rs = ps.executeQuery();

            while (rs.next()) {
                Lab lab = new Lab();
                lab.setLabId(rs.getString("labId"));

                equipmentList.add(new Equipment(
                        rs.getString("equipmentId"),
                        rs.getString("equipmentName"),
                        rs.getString("status"),
                        lab
                ));
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return equipmentList;
    }

    @Override
    public List<Equipment> findByLab(String labId) {
        List<Equipment> equipmentList = new ArrayList<>();
        try {
            String sql = "SELECT * FROM Equipment WHERE labId=?";
            PreparedStatement ps = connection.prepareStatement(sql);
            ps.setString(1, labId);
            ResultSet rs = ps.executeQuery();

            while (rs.next()) {
                Lab lab = new Lab();
                lab.setLabId(rs.getString("labId"));

                equipmentList.add(new Equipment(
                        rs.getString("equipmentId"),
                        rs.getString("equipmentName"),
                        rs.getString("status"),
                        lab
                ));
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return equipmentList;
    }
}
