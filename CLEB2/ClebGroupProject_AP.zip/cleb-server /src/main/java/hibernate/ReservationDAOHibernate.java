package hibernate;

import java.util.List;

import org.hibernate.Session;
import org.hibernate.Transaction;

import dao.Reservation;
import dao.ReservationDAO;
import factories.HibernateSessionFactory;
import models.Reservation;
import models.ReservationStatus;

public class ReservationDAOHibernate implements ReservationDAO{

    @Override
    public void save(ReservationDAO reservation) {
        Transaction tx = null;
        try (Session session = HibernateSessionFactory.getSessionFactory().openSession()) {
            tx = session.beginTransaction();
            session.persist(reservation);
            tx.commit();
            System.out.println("Reservation saved with Hibernate.");
        } catch (Exception e) {
            if (tx != null) tx.rollback();
            e.printStackTrace();
        }
    }

    @Override
    public void update(Reservation reservation {
        Transaction tx = null;
        try (Session session = HibernateSessionFactory.getSessionFactory().openSession()) {
            tx = session.beginTransaction();
            session.merge(reservation);
            tx.commit();
            System.out.println("Reservation updated with Hibernate.");
        } catch (Exception e) {
            if (tx != null) tx.rollback();
            e.printStackTrace();
        }
    }

    @Override
    public void delete(String reservationId) {
        Transaction tx = null;
        try (Session session = HibernateSessionFactory.getSessionFactory().openSession()) {
            tx = session.beginTransaction();
            Reservation reservation = session.get(Reservation.class, reservationId);
            if (reservation != null) {
                session.remove(reservation);
            }
            tx.commit();
            System.out.println("Reservation deleted with Hibernate.");
        } catch (Exception e) {
            if (tx != null) tx.rollback();
            e.printStackTrace();
        }
    }

    @Override
    public Reservation findById(String reservationId) {
        try (Session session = HibernateSessionFactory.getSessionFactory().openSession()) {
            return session.get(Reservation.class, reservationId);
        }
    }

    @Override
    public List<Reservation> findAll() {
        try (Session session = HibernateSessionFactory.getSessionFactory().openSession()) {
            return session.createQuery("FROM Reservation", Reservation.class).list();
        }
    }

    @Override
    public List<Reservation> findByUser(String userId) {
        try (Session session = HibernateSessionFactory.getSessionFactory().openSession()) {
            return session.createQuery("FROM Reservation r WHERE r.user.userId = :userId", Reservation.class)
                    .setParameter("userId", userId)
                    .list();
        }
    }

    @Override
    public List<Reservation> findByStatus(ReservationStatus status) {
        try (Session session = HibernateSessionFactory.getSessionFactory().openSession()) {
            return session.createQuery("FROM Reservation r WHERE r.status = :status", Reservation.class)
                    .setParameter("status", status)
                    .list();
        }
    }

	@Override
	public void save(model.Reservation reservation) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void update(model.Reservation reservation) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public List<model.Reservation> findByStatus(model.ReservationStatus status) {
		// TODO Auto-generated method stub
		return null;
	}
}