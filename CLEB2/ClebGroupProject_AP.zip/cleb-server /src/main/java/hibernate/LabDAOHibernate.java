package hibernate;

import java.util.List;

import org.hibernate.Session;
import org.hibernate.Transaction;

import dao.LabDAO;
import factories.HibernateSessionFactory;
import model.Lab;

public class LabDAOHibernate implements LabDAO {

    @Override
    public void save(Lab lab) {
        Transaction tx = null;
        try (Session session = HibernateSessionFactory.getSessionFactory().openSession()) {
            tx = session.beginTransaction();
            session.persist(lab);
            tx.commit();
            System.out.println("Lab saved with Hibernate.");
        } catch (Exception e) {
            if (tx != null) tx.rollback();
            e.printStackTrace();
        }
    }

    @Override
    public void update(Lab lab) {
        Transaction tx = null;
        try (Session session = HibernateSessionFactory.getSessionFactory().openSession()) {
            tx = session.beginTransaction();
            session.merge(lab);
            tx.commit();
            System.out.println("Lab updated with Hibernate.");
        } catch (Exception e) {
            if (tx != null) tx.rollback();
            e.printStackTrace();
        }
    }

    @Override
    public void delete(String labId) {
        Transaction tx = null;
        try (Session session = HibernateSessionFactory.getSessionFactory().openSession()) {
            tx = session.beginTransaction();
            Lab lab = session.get(Lab.class, labId);
            if (lab != null) {
                session.remove(lab);
            }
            tx.commit();
            System.out.println("Lab deleted with Hibernate.");
        } catch (Exception e) {
            if (tx != null) tx.rollback();
            e.printStackTrace();
        }
    }

    @Override
    public Lab findById(String labId) {
        try (Session session = HibernateSessionFactory.getSessionFactory().openSession()) {
            return session.get(Lab.class, labId);
        }
    }

    @Override
    public List<Lab> findAll() {
        try (Session session = HibernateSessionFactory.getSessionFactory().openSession()) {
            return session.createQuery("FROM Lab", Lab.class).list();
        }
    }
}