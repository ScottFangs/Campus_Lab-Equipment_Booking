package hibernate;

import java.util.List;

import org.hibernate.Session;
import org.hibernate.Transaction;

import dao.EquipmentDAO;
import factories.HibernateSessionFactory;
import model.Equipment;

public class EquipmentDAOHibernate implements EquipmentDAO {

    @Override
    public void save(Equipment equipment) {
        Transaction tx = null;
        try (Session session = HibernateSessionFactory.getSessionFactory().openSession()) {
            tx = session.beginTransaction();
            session.persist(equipment);
            tx.commit();
            System.out.println("Equipment saved with Hibernate.");
        } catch (Exception e) {
            if (tx != null) tx.rollback();
            e.printStackTrace();
        }
    }

    @Override
    public void update(Equipment equipment) {
        Transaction tx = null;
        try (Session session = HibernateSessionFactory.getSessionFactory().openSession()) {
            tx = session.beginTransaction();
            session.merge(equipment);
            tx.commit();
            System.out.println("Equipment updated with Hibernate.");
        } catch (Exception e) {
            if (tx != null) tx.rollback();
            e.printStackTrace();
        }
    }

    @Override
    public void delete(String equipmentId) {
        Transaction tx = null;
        try (Session session = HibernateSessionFactory.getSessionFactory().openSession()) {
            tx = session.beginTransaction();
            Equipment equipment = session.get(Equipment.class, equipmentId);
            if (equipment != null) {
                session.remove(equipment);
            }
            tx.commit();
            System.out.println("Equipment deleted with Hibernate.");
        } catch (Exception e) {
            if (tx != null) tx.rollback();
            e.printStackTrace();
        }
    }

    @Override
    public Equipment findById(String equipmentId) {
        try (Session session = HibernateSessionFactory.getSessionFactory().openSession()) {
            return session.get(Equipment.class, equipmentId);
        }
    }

    @Override
    public List<Equipment> findAll() {
        try (Session session = HibernateSessionFactory.getSessionFactory().openSession()) {
            return session.createQuery("FROM Equipment", Equipment.class).list();
        }
    }

    @Override
    public List<Equipment> findByLab(String labId) {
        try (Session session = HibernateSessionFactory.getSessionFactory().openSession()) {
            return session.createQuery("FROM Equipment e WHERE e.lab.labId = :labId", Equipment.class)
                    .setParameter("labId", labId)
                    .list();
        }
    }
}