package model;

import jakarta.persistence.*;

@Entity
@Table(name = "Labs")
public class Lab {

    @Id
    @Column(name = "labId")
    private String labId;

    @Column(name = "labName")
    private String labName;

    @Column(name = "campus")
    private String campus;

    @Column(name = "seatCapacity")
    private int seatCapacity;

    public Lab() {
    }

    public Lab(String labId, String labName, String campus, int seatCapacity) {
        this.labId = labId;
        this.labName = labName;
        this.campus = campus;
        this.seatCapacity = seatCapacity;
    }

    public String getLabId() { return labId; }
    public void setLabId(String labId) { this.labId = labId; }
    public String getLabName() { return labName; }
    public void setLabName(String labName) { this.labName = labName; }
    public String getCampus() { return campus; }
    public void setCampus(String campus) { this.campus = campus; }
    public int getSeatCapacity() { return seatCapacity; }
    public void setSeatCapacity(int seatCapacity) { this.seatCapacity = seatCapacity; }
}
