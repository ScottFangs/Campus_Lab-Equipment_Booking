package model;

public enum Role {
    STUDENT,
    TECHNICIAN,
    ADMIN
}
