package model;

import jakarta.persistence.*;

@Entity
@Table(name = "Equipment")
public class Equipment {

    @Id
    @Column(name = "equipmentId")
    private String equipmentId;

    @Column(name = "equipmentName")
    private String equipmentName;

    @Column(name = "status")
    private String status;

    @ManyToOne
    @JoinColumn(name = "labId")
    private Lab lab;

    public Equipment() {
    }

    public Equipment(String equipmentId, String equipmentName, String status, Lab lab) {
        this.equipmentId = equipmentId;
        this.equipmentName = equipmentName;
        this.status = status;
        this.lab = lab;
    }

    public String getEquipmentId() { return equipmentId; }
    public void setEquipmentId(String equipmentId) { this.equipmentId = equipmentId; }
    public String getEquipmentName() { return equipmentName; }
    public void setEquipmentName(String equipmentName) { this.equipmentName = equipmentName; }
    public String getStatus() { return status; }
    public void setStatus(String status) { this.status = status; }
    public Lab getLab() { return lab; }
    public void setLab(Lab lab) { this.lab = lab; }
}