package model;

import java.time.LocalDate;
import java.time.LocalTime;

import jakarta.persistence.*;

@Entity
@Table(name = "Reservations")
public class Reservation {

    @Id
    @Column(name = "reservationId")
    private String reservationId;

    @ManyToOne
    @JoinColumn(name = "userId")
    private User user;

    @ManyToOne
    @JoinColumn(name = "labId")
    private Lab lab;

    @ManyToOne
    @JoinColumn(name = "equipmentId")
    private Equipment equipment;

    @Column(name = "seatNumber")
    private String seatNumber;

    @Column(name = "bookingDate")
    private LocalDate bookingDate;

    @Column(name = "startTime")
    private LocalTime startTime;

    @Column(name = "endTime")
    private LocalTime endTime;

    @Enumerated(EnumType.STRING)
    @Column(name = "status")
    private ReservationStatus status;

    public Reservation() {
    }

    public Reservation(String reservationId, User user, Lab lab, Equipment equipment,
            String seatNumber, LocalDate bookingDate, LocalTime startTime,
            LocalTime endTime, ReservationStatus status) {
        this.reservationId = reservationId;
        this.user = user;
        this.lab = lab;
        this.equipment = equipment;
        this.seatNumber = seatNumber;
        this.bookingDate = bookingDate;
        this.startTime = startTime;
        this.endTime = endTime;
        this.status = status;
    }

    public String getReservationId() { return reservationId; }
    public void setReservationId(String reservationId) { this.reservationId = reservationId; }
    public User getUser() { return user; }
    public void setUser(User user) { this.user = user; }
    public Lab getLab() { return lab; }
    public void setLab(Lab lab) { this.lab = lab; }
    public Equipment getEquipment() { return equipment; }
    public void setEquipment(Equipment equipment) { this.equipment = equipment; }
    public String getSeatNumber() { return seatNumber; }
    public void setSeatNumber(String seatNumber) { this.seatNumber = seatNumber; }
    public LocalDate getBookingDate() { return bookingDate; }
    public void setBookingDate(LocalDate bookingDate) { this.bookingDate = bookingDate; }
    public LocalTime getStartTime() { return startTime; }
    public void setStartTime(LocalTime startTime) { this.startTime = startTime; }
    public LocalTime getEndTime() { return endTime; }
    public void setEndTime(LocalTime endTime) { this.endTime = endTime; }
    public ReservationStatus getStatus() { return status; }
    public void setStatus(ReservationStatus status) { this.status = status; }
}
