package model;

public enum ReservationStatus {
    PENDING,
    APPROVED,
    REJECTED,
    CANCELLED
}
