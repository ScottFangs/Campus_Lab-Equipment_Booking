package dao;

import java.util.List;

import model.Reservation;
import model.ReservationStatus;

public interface ReservationDAO {
    Reservation createReservation(Reservation reservation);
    List<Reservation> getPendingReservations();
    List<Reservation> getAllReservations();
    void approveReservation(long reservationId);
    void rejectReservation(long reservationId);
    void cancelReservation(long reservationId);
	void setStatus(String string);
}