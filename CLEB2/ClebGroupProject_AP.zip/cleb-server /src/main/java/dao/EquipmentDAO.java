package dao;

import java.util.List;
import model.Equipment;

public interface EquipmentDAO {
    void save(Equipment equipment);
    void update(Equipment equipment);
    void delete(String equipmentId);
    Equipment findById(String equipmentId);
    List<Equipment> findAll();
    List<Equipment> findByLab(String labId);
}
