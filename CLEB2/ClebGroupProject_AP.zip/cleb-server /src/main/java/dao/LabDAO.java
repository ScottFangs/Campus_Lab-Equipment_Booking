package dao;

import java.util.List;
import model.Lab;

public interface LabDAO {
    void save(Lab lab);
    void update(Lab lab);
    void delete(String labId);
    Lab findById(String labId);
    List<Lab> findAll();
}