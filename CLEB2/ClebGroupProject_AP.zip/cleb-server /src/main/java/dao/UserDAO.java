package dao;

import java.util.List;
import model.User;

public interface UserDAO {
    void save(User user);
    void update(User user);
    void delete(String userId);
    User findById(String userId);
    User findByEmail(String email);
    List<User> findAll();
}
