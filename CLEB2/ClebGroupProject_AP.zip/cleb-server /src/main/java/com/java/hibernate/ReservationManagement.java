package com.java.hibernate;

import java.util.List;

import dao.ReservationDAO;

public interface ReservationManagement {

    void exit();
    void create(ReservationDAO reservation);
    void read(long reservationId);
    void update(ReservationDAO reservation);
    void delete(long reservationId);

    List<ReservationDAO> getAllReservations();
    List<ReservationDAO> getPendingReservations();
    List<ReservationDAO> getReservationsByUser(long userId);
}
