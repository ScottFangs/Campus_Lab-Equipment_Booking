package com.java.hibernate;

import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

import dao.ReservationDAO;

public class ReservationManager implements ReservationManagement {

    private static SessionFactory sessionFactory = null;

    public ReservationManager() {
        sessionFactory = buildSessionFactory();
    }

    private static SessionFactory buildSessionFactory() {
        try {
            return new Configuration().configure().buildSessionFactory();
        } catch (Exception e) {
            System.err.println("SessionFactory creation failed: " + e);
            throw new ExceptionInInitializerError(e);
        }
    }

    public static SessionFactory getSessionFactory() {
        return sessionFactory;
    }

    @Override
    public void exit() {
        sessionFactory.close();
    }

    @Override
    public void create(ReservationDAO reservation) {
        Session session = sessionFactory.openSession();
        session.beginTransaction();

        session.persist(reservation);

        session.getTransaction().commit();
        session.close();
    }

    @Override
    public void read(long reservationId) {
        Session session = sessionFactory.openSession();
        session.beginTransaction();

        ReservationDAO reservation = session.get(ReservationDAO.class, reservationId);

        if (reservation != null) {
            System.out.println(reservation);
        } else {
            System.out.println("Reservation not found");
        }

        session.getTransaction().commit();
        session.close();
    }

    @Override
    public void update(ReservationDAO reservation) {
        Session session = sessionFactory.openSession();
        session.beginTransaction();

        session.merge(reservation);

        session.getTransaction().commit();
        session.close();
    }

    @Override
    public void delete(long reservationId) {
        Session session = sessionFactory.openSession();
        session.beginTransaction();

        ReservationDAO reservation = session.get(ReservationDAO.class, reservationId);
        if (reservation != null) {
            session.remove(reservation);
        } else {
            System.out.println("Reservation not found");
        }

        session.getTransaction().commit();
        session.close();
    }

    @Override
    public List<ReservationDAO> getAllReservations() {
        Session session = sessionFactory.openSession();
        session.beginTransaction();

        List<ReservationDAO> reservations =
                session.createQuery("FROM Reservation", ReservationDAO.class).list();

        session.getTransaction().commit();
        session.close();

        return reservations;
    }

    @Override
    public List<ReservationDAO> getPendingReservations() {
        Session session = sessionFactory.openSession();
        session.beginTransaction();

        List<ReservationDAO> reservations = session.createQuery(
                "FROM Reservation r WHERE r.status = :status", ReservationDAO.class)
                .setParameter("status", "PENDING")
                .list();

        session.getTransaction().commit();
        session.close();

        return reservations;
    }

    @Override
    public List<ReservationDAO> getReservationsByUser(long userId) {
        Session session = sessionFactory.openSession();
        session.beginTransaction();

        List<ReservationDAO> reservations = session.createQuery(
                "FROM Reservation r WHERE r.user.userId = :userId", ReservationDAO.class)
                .setParameter("userId", userId)
                .list();

        session.getTransaction().commit();
        session.close();

        return reservations;
    }

    public void approve(long reservationId) {
        Session session = sessionFactory.openSession();
        session.beginTransaction();

        ReservationDAO reservation = session.get(ReservationDAO.class, reservationId);
        if (reservation != null) {
            reservation.setStatus("APPROVED");
            session.merge(reservation);
        } else {
            System.out.println("Reservation not found");
        }

        session.getTransaction().commit();
        session.close();
    }

    public void reject(long reservationId) {
        Session session = sessionFactory.openSession();
        session.beginTransaction();

        ReservationDAO reservation = session.get(ReservationDAO.class, reservationId);
        if (reservation != null) {
            reservation.setStatus("REJECTED");
            session.merge(reservation);
        } else {
            System.out.println("Reservation not found");
        }

        session.getTransaction().commit();
        session.close();
    }

    public void cancel(long reservationId) {
        Session session = sessionFactory.openSession();
        session.beginTransaction();

        ReservationDAO reservation = session.get(ReservationDAO.class, reservationId);
        if (reservation != null) {
            reservation.setStatus("CANCELLED");
            session.merge(reservation);
        } else {
            System.out.println("Reservation not found");
        }

        session.getTransaction().commit();
        session.close();
    }

    public static void main(String[] args) {
        ReservationManager manager = new ReservationManager();

        // manager.read(1);

        List<ReservationDAO> reservations = manager.getPendingReservations();
        for (ReservationDAO r : reservations) {
            System.out.println(r);
        }

        manager.exit();
    }
}