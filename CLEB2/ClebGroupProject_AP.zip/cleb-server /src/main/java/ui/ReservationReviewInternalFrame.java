package ui;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;

import dao.ReservationDAO;
import daoimpl.ReservationDAOJdbc;
import model.Reservation;

import java.awt.*;
import java.util.List;

public class ReservationReviewInternalFrame extends JInternalFrame {

    private JTable table;
    private DefaultTableModel tableModel;

    private JButton approveButton;
    private JButton rejectButton;
    private JButton cancelButton;
    private JButton refreshButton;

    private ReservationDAO reservationDAO;

    public ReservationReviewInternalFrame() {
        super("Pending Reservations Review", true, true, true, true);

        reservationDAO = new ReservationDAOJdbc();

        setSize(900, 400);
        setLayout(new BorderLayout());

        tableModel = new DefaultTableModel(
                new Object[]{"Reservation ID", "Username", "Start Time", "End Time", "Status"},
                0
        ) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };

        table = new JTable(tableModel);
        JScrollPane scrollPane = new JScrollPane(table);

        JPanel buttonPanel = new JPanel(new FlowLayout());

        approveButton = new JButton("Approve");
        rejectButton = new JButton("Reject");
        cancelButton = new JButton("Cancel");
        refreshButton = new JButton("Refresh");

        buttonPanel.add(approveButton);
        buttonPanel.add(rejectButton);
        buttonPanel.add(cancelButton);
        buttonPanel.add(refreshButton);

        add(scrollPane, BorderLayout.CENTER);
        add(buttonPanel, BorderLayout.SOUTH);

        loadPendingReservations();
        registerEvents();
    }

    private void loadPendingReservations() {
        tableModel.setRowCount(0);

        List<Reservation> reservations = reservationDAO.getPendingReservations();

        for (Reservation reservation : reservations) {
            tableModel.addRow(new Object[]{
                    reservation.getReservationId(),
                    reservation.getBookedBy() != null ? reservation.getBookedBy().getUsername() : "",
                    reservation.getStartTime(),
                    reservation.getEndTime(),
                    reservation.getStatus()
            });
        }
    }

    private void registerEvents() {
        approveButton.addActionListener(e -> {
            Long reservationId = getSelectedReservationId();
            if (reservationId == null) {
                return;
            }

            reservationDAO.approveReservation(reservationId);
            JOptionPane.showMessageDialog(this, "Reservation approved.");
            loadPendingReservations();
        });

        rejectButton.addActionListener(e -> {
            Long reservationId = getSelectedReservationId();
            if (reservationId == null) {
                return;
            }

            reservationDAO.rejectReservation(reservationId);
            JOptionPane.showMessageDialog(this, "Reservation rejected.");
            loadPendingReservations();
        });

        cancelButton.addActionListener(e -> {
            Long reservationId = getSelectedReservationId();
            if (reservationId == null) {
                return;
            }

            reservationDAO.cancelReservation(reservationId);
            JOptionPane.showMessageDialog(this, "Reservation cancelled.");
            loadPendingReservations();
        });

        refreshButton.addActionListener(e -> loadPendingReservations());
    }

    private Long getSelectedReservationId() {
        int selectedRow = table.getSelectedRow();

        if (selectedRow == -1) {
            JOptionPane.showMessageDialog(this, "Please select a reservation first.");
            return null;
        }

        Object value = tableModel.getValueAt(selectedRow, 0);
        return Long.parseLong(value.toString());
    }
}