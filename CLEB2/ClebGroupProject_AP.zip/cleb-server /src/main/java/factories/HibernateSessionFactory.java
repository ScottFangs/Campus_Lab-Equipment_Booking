package factories;

import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

import model.Equipment;
import model.Lab;
import model.Reservation;
import model.User;

public class HibernateSessionFactory {

    private static SessionFactory sessionFactory = null;

    public static SessionFactory getSessionFactory() {
        if (sessionFactory == null) {
            try {
                sessionFactory = new Configuration()
                        .configure("hibernate.cfg.xml")
                        .addAnnotatedClass(User.class)
                        .addAnnotatedClass(Lab.class)
                        .addAnnotatedClass(Equipment.class)
                        .addAnnotatedClass(Reservation.class)
                        .buildSessionFactory();

                System.out.println("Hibernate SessionFactory created!");
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
        return sessionFactory;
    }
}
