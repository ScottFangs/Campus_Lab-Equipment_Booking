package factories;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class DBConnectionFactory {

    private static Connection connection = null;

    public static Connection getConnection() {
        if (connection == null) {
            try {
                String url = "jdbc:mysql://localhost:3306/clebdb";
                String username = "root";
                String password = "";

                connection = DriverManager.getConnection(url, username, password);
                System.out.println("Database connection created!");
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
        return connection;
    }
}
